package com.example.pr15rymarev;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Получимссылкунасолнце
        ImageView sunImageView = findViewById(R.id.sun);
        // Анимациядлявосходасолнца
        Animation sunRiseAnimation = AnimationUtils.loadAnimation(this, R.anim.sun_rise);
        // Подключаеманимациюкнужному View
        sunImageView.startAnimation(sunRiseAnimation);
    }
}
